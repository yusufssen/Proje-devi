import datetime
from hasta import Hasta
from doktor import Doktor
from randevu import Randevu
from PyQt5.QtCore import QDateTime
'''
bu modülde RandevuSistemi sınıfı tanımlanmıştır. Bu sınıf, hastane randevu sisteminin işleyişini ve işlemlerini tanımlar.
hasta ve doktor ekleyebilir, randevu ekleyebilir ve  güncelleyebilir.
verilen bir doktor veya hastanın randevularını listeleyebilir
'''
class RandevuSistemi:
    def __init__(self):
        self.hastalar = {}
        self.doktorlar = {}
        self.randevular = []
# test verileri
        # self.doktor_kayit(Doktor("Dr. Ahmet", "12345678901", "Kardiyoloji"))
        # self.doktor_kayit(Doktor("Dr. Ayşe", "23456789012", "Ortopedi"))
        # self.doktor_kayit(Doktor("Dr Mehmet", "34567890123", "Dahiliye"))
        # self.doktor_kayit(Doktor("Dr. Ali", "45678901234", "Göz Hastalıkları")) 
        # self.doktor_kayit(Doktor("Dr. Veli", "56789012345", "Kulak Burun Boğaz"))
        # self.hasta_kayit(Hasta("Ali", "12345678901"))
        # self.hasta_kayit(Hasta("Veli", "23456789012"))
        # self.hasta_kayit(Hasta("Ayşe", "34567890123"))


    def hasta_kayit(self, hasta): # hasta ekler
            self.hastalar[hasta.tc_no] = hasta

    def doktor_kayit(self,doktor):  # doktor ekler
            self.doktorlar[doktor.tc] = doktor

    def randevuEkle(self, doktor, hasta, tarih, durum='Gelecek'): # randevu ekler
        if doktor.musaitMi(tarih):
            randevu = Randevu(doktor, hasta, tarih , durum)
            self.randevular.append(randevu)
            return randevu
        else:
            raise ValueError('Doktor bu tarih/saatte müsait değil.')

    def randevuGuncelle(self, randevu_id, durum): # randevu durumunu günceller
        for randevu in self.randevular:
            if randevu.id == randevu_id:
                randevu.durum = durum
                return randevu
        raise ValueError('Randevu bulunamadı.')

    def doktorRandevulari(self, doktor): # doktorun randevularını döndürür, eğer randevu tarihi geçmişse durumunu güncelle
        for randevu in self.randevular:
            if randevu.doktor == doktor:# tarih normal py datetime olduğu için karşılaştırma yapılabilir
                if randevu.tarih < datetime.datetime.now() and randevu.durum != 'İptal Edildi':
                    randevu.durum = 'Geçmiş'
        return [randevu for randevu in self.randevular if randevu.doktor == doktor]
    
    def hastaRandevulari(self, hasta): # hastanın randevularını döndürür eğer randevu tarihi geçmişse durumunu güncelle
        for randevu in self.randevular:
            if randevu.hasta == hasta:
                if randevu.tarih <datetime.datetime.now() and randevu.durum != 'İptal Edildi':
                    randevu.durum = 'Geçmiş'
        return [randevu for randevu in self.randevular if randevu.hasta == hasta]