
from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QDateTimeEdit, QTableWidget,QHeaderView,QTableWidgetItem,
                             QComboBox,  QMessageBox)
from PyQt5.QtCore import QDateTime
from PyQt5.QtCore import Qt

'''
Hasane randevu sisteminin hasta paneli penceresini oluşturur.
Hastalar, alan seçerek ilgili doktorları görüp istedikleri doktordan randevu alabilir.
Hastalar gelecek tarihli ve doktorun müsait olduğu tarihlere randevu alabilir.
Gelecek randevuları iptal edebilir.
Tüm randevu kayıtlarını görebilir ve yönetebilir.
'''

class HastaPaneli(QWidget):
    def __init__(self, hasta, sistem):
        super().__init__()
        self.hasta = hasta
        self.sistem = sistem
        self.setWindowTitle(f'{hasta.isim} - Hasta Paneli')
        self.setGeometry(100, 100, 1000, 400)
        self.initUI()

    def initUI(self):
        layout = QHBoxLayout()

        # Randevu Alma Bölümü
        randevu_alma_alani = QVBoxLayout()
        randevu_alma_alani.addWidget(QLabel('Hoşgeldiniz, ' + self.hasta.isim))
        randevu_alma_alani.addWidget(QLabel('Randevu Talebi'))

        # alan seçimi
        self.alan_secim = QComboBox()
        self.alan_secim.addItems(['Kardiyoloji', 'Ortopedi', 'Dahiliye', 'Göz Hastalıkları', 'Kulak Burun Boğaz'])
        self.alan_secim.currentIndexChanged.connect(self.doktorListele)  # Update doctors on specialty change
        randevu_alma_alani.addWidget(self.alan_secim)
        # Doktor seçimi
        self.doktor_secim = QComboBox()
        randevu_alma_alani.addWidget(self.doktor_secim)
        self.doktorListele()

        self.tarih_secici = QDateTimeEdit(QDateTime.currentDateTime())
        self.tarih_secici.setCalendarPopup(True)
        randevu_alma_alani.addWidget(self.tarih_secici)

        randevu_al_button = QPushButton('Randevu Al')
        randevu_al_button.clicked.connect(self.randevu_al)
        randevu_alma_alani.addWidget(randevu_al_button)

        layout.addLayout(randevu_alma_alani)

        gecmis_randevular = QVBoxLayout()
        gecmis_randevular.addWidget(QLabel('Geçmiş Randevular'))

        # Randevular Tablosu
        self.randevular_tablo = QTableWidget(0, 6) 
        self.randevular_tablo.setHorizontalHeaderLabels(['Tarih', 'Alan', 'Doktor', 'Durum', 'Randevu ID','İptal'])
        self.randevular_tablo.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.randevular_tablo.setEditTriggers(QTableWidget.NoEditTriggers)
        self.randevulari_goster()
        gecmis_randevular.addWidget(self.randevular_tablo)
        layout.addLayout(gecmis_randevular)
        self.setStyleSheet("""
            QWidget {
                font-family: Calibri;
                font-size: 25px;
                background-color: #09684d;
                color: white;
                border: 2px solid white; 
            }
            QLineEdit {
                background-color: white;
                color: black;
                border: 1px solid #ccc; 
            }
            QHeaderView::section {
                background-color: #0b9161;
                color: white;
                padding: 4px;
                border: 1px solid white; 
            }
        QPushButton {
                background-color: white;
                color: green;
                font-family: Calibri;
                font-size: 25px;
            }
        """)
        self.setLayout(layout)

# randevuyu iptal eder
    def randevuİptal(self,randevu_id):
        self.sistem.randevuGuncelle(randevu_id, 'İptal Edildi')
        self.randevulari_goster()

# iptal butonu ekler
    def iptalButonuEkle(self,row, randevu_id):
        btn=QPushButton("İptal")
        btn.clicked.connect(lambda: self.randevuİptal(randevu_id))
        self.randevular_tablo.setCellWidget(row,5,btn)

# doktorları alan seçimine göre listeler
    def doktorListele(self):
        self.doktor_secim.clear()
        chosen_specialty = self.alan_secim.currentText()
        filtered_doctors = [doktor for doktor in self.sistem.doktorlar.values() if doktor.uzmanlik_alani == chosen_specialty]
        for doktor in filtered_doctors:
            self.doktor_secim.addItem(doktor.isim)

# hastaya randevu alır
    def randevu_al(self):
        doktor_adi = self.doktor_secim.currentText()
        doktor = next((doc for doc in self.sistem.doktorlar.values() if doc.isim == doktor_adi), None)
        tarih = self.tarih_secici.dateTime().toPyDateTime()

        if doktor:
            try:
                self.sistem.randevuEkle(doktor, self.hasta, tarih, durum='Gelecek')
            except ValueError as e: 
                QMessageBox.warning(self, 'Hata', str(e))
            else:
                 QMessageBox.information(self, 'Başarılı', 'Randevunuz alındı.')
                 self.randevulari_goster()
        else:
            QMessageBox.warning(self, 'Hata', 'Doktor bulunamadı.')

# hastanın randevularını tabloda gösterir
    def randevulari_goster(self):
        self.randevular_tablo.clearContents()
        self.randevular_tablo.setRowCount(0)
        randevular = self.sistem.hastaRandevulari(self.hasta)
        for randevu in randevular:
            row = self.randevular_tablo.rowCount()
            self.randevular_tablo.insertRow(row)
            self.randevular_tablo.setItem(row, 0, QTableWidgetItem(randevu.tarih.strftime('%Y-%m-%d %H:%M')))
            self.randevular_tablo.setItem(row, 1, QTableWidgetItem(randevu.doktor.uzmanlik_alani))
            self.randevular_tablo.setItem(row, 2, QTableWidgetItem(randevu.doktor.isim))
            self.randevular_tablo.setItem(row, 3, QTableWidgetItem(randevu.durum))
            self.randevular_tablo.setItem(row, 4, QTableWidgetItem(str(randevu.id)))
            if randevu.durum == 'İptal Edildi': 
                self.randevular_tablo.item(row, 3).setBackground(Qt.red)
            elif randevu.durum == 'Geçmiş': 
                self.randevular_tablo.item(row, 3).setBackground(Qt.darkGray)
            else:
                self.iptalButonuEkle(row,randevu.id)

                                          
