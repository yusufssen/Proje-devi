from randevu import Randevu

'''
Bu modülde Hasta sınıfı tanımlanmıştır. Bu sınıf, bir hastanın özelliklerini tanımlar.
'''
class Hasta:
    def __init__(self, isim, tc_no):
        self.isim = isim
        self.tc_no = tc_no
