import sys
from PyQt5.QtWidgets import QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QLineEdit, QPushButton, QLabel, QFrame, QMessageBox,QComboBox
from PyQt5.QtGui import QIntValidator
from sistem import RandevuSistemi
from doktor_paneli import DoktorPaneli
from hasta_paneli import HastaPaneli
from doktor import Doktor
from hasta import Hasta

'''
Bu sınıf, hastane randevu sisteminin ana giriş penceresini oluşturur.
Hasta ve doktor kayıtlarını yapar, giriş yapar ve ilgili paneli açar.
'''

class AnaPencere(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle('Hastane Randevu Sistemi')
        self.setGeometry(200, 200, 700, 300)
        self.sistem = RandevuSistemi()
        self.doktor_paneli = None  
        self.hasta_paneli = None
        self.initUI()

    def initUI(self):
        ana_konteyner = QWidget()
        self.setCentralWidget(ana_konteyner)
        ana_layout = QHBoxLayout()
        ana_konteyner.setLayout(ana_layout)

        # Hasta tarafı
        hasta_konteyner = QVBoxLayout()
        hasta_baslik = QLabel("Hasta Kayıt ve Giriş")
        hasta_baslik.setStyleSheet("font-weight: bold; font-size: 25px;")
        hasta_isim = QLineEdit()
        hasta_isim.setPlaceholderText("İsim")
        hasta_tc_no = QLineEdit()
        hasta_tc_no.setValidator(QIntValidator())
        hasta_tc_no.setPlaceholderText("TC No")
        hasta_kayit_buton = QPushButton("Kayıt Ol")
        hasta_kayit_buton.clicked.connect(lambda: self.hastaKayit( hasta_isim.text(), hasta_tc_no.text())  )
        hasta_giris_buton = QPushButton("Giriş Yap")
        hasta_giris_buton.clicked.connect(lambda: self.giris( hasta_isim.text(), hasta_tc_no.text(),'hasta'))

        hasta_konteyner.addWidget(hasta_baslik)
        hasta_konteyner.addWidget(hasta_isim)
        hasta_konteyner.addWidget(hasta_tc_no)
        hasta_konteyner.addWidget(hasta_kayit_buton)
        hasta_konteyner.addWidget(hasta_giris_buton)

        # Doktor tarafı
        doktor_konteyner = QVBoxLayout()
        doktor_baslik = QLabel("Doktor Kayıt ve Giriş")
        doktor_baslik.setStyleSheet("font-weight: bold; font-size: 25px;")
        doktor_isim = QLineEdit()
        doktor_isim.setPlaceholderText("İsim")
       # Uzmanlık Alanı ComboBox
        doktor_uzmanlik = QComboBox()
        doktor_uzmanlik.addItems(['Kardiyoloji', 'Ortopedi', 'Dahiliye', 'Göz Hastalıkları', 'Kulak Burun Boğaz'])
        doktor_tc = QLineEdit()
        doktor_tc.setPlaceholderText("TC kimlik no")
        doktor_tc.setValidator(QIntValidator())
        
        doktor_kayit_buton = QPushButton("Kayıt Ol")
        doktor_kayit_buton.clicked.connect(lambda: self.doktorKayit(doktor_isim.text(), doktor_tc.text(), doktor_uzmanlik.currentText()))

        doktor_giris_buton = QPushButton("Giriş Yap")
        doktor_giris_buton.clicked.connect(lambda: self.giris(doktor_isim.text(), doktor_tc.text(), 'doktor'))

        doktor_konteyner.addWidget(doktor_baslik)
        doktor_konteyner.addWidget(doktor_isim)
        doktor_konteyner.addWidget(doktor_tc)
        doktor_konteyner.addWidget(doktor_uzmanlik)
        doktor_konteyner.addWidget(doktor_kayit_buton)
        doktor_konteyner.addWidget(doktor_giris_buton)


        # Çizgi Ekleme
        cizgi = QFrame()
        cizgi.setFrameShape(QFrame.VLine)
        cizgi.setFrameShadow(QFrame.Sunken)
        #tüm fontları calibri 25px yap, renkleri değiştir
        # qlineedit'leri standart rengte bırak
        # pushbuttonları beyaz yap, yazı rengini yeşil yap
        self.setStyleSheet("""
            QWidget {
                font-family: Calibri; 
                font-size: 25px; 
                background-color: #0b9161; 
                color: white;
            }
            QLineEdit {
                background-color: white; 
                color: black;
            }
            QPushButton {
                background-color: white; 
                color: green;
            }

        """)
        ana_layout.addLayout(hasta_konteyner)
        ana_layout.addWidget(cizgi)
        ana_layout.addLayout(doktor_konteyner)
        
        ana_konteyner.setLayout(ana_layout)

# hasta kayıtlarını yapar
    def hastaKayit(self,isim, tc):
        if tc in self.sistem.hastalar.keys():
            QMessageBox.warning(self, 'Hata', 'Bu TC no ile bir hasta zaten kayıtlı.')
        else:
            self.sistem.hasta_kayit (Hasta(isim, tc))
            QMessageBox.information(self, 'Başarılı', 'Hasta kaydı başarılı.')

# doktor kayıtlarını yapar
    def doktorKayit(self, isim, tc, uzmanlik):
        if tc in self.sistem.doktorlar.keys():
            QMessageBox.warning(self, 'Hata', 'Bu TC no ile bir doktor zaten kayıtlı.')
        else:
            self.sistem.doktor_kayit(Doktor(isim,tc, uzmanlik))
            QMessageBox.information(self, 'Başarılı', 'Doktor kaydı başarılı.')

# giriş yapar ve ilgili paneli açar
    def giris(self, isim, tc, tip):
        if tip == 'hasta':
            if tc in self.sistem.hastalar.keys():
                hasta = self.sistem.hastalar[tc]
                self.hasta_paneli = HastaPaneli(hasta, self.sistem)
                self.hasta_paneli.show()
                
            else:
                QMessageBox.warning(self, 'Hata', 'Hasta bulunamadı.')
        elif tip == 'doktor':
            if tc in self.sistem.doktorlar.keys() and self.sistem.doktorlar[tc].isim == isim:
                doktor = self.sistem.doktorlar[tc]
                self.doktor_paneli = DoktorPaneli(doktor, self.sistem)  # Keep the reference at the class level
                self.doktor_paneli.show()
                
            else:
                QMessageBox.warning(self, 'Hata', 'Doktor bulunamadı.')

if __name__ == '__main__':
    app = QApplication(sys.argv)
    pencere = AnaPencere()
    pencere.show()
    sys.exit(app.exec_())
