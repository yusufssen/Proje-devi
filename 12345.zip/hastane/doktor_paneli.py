from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QDateTimeEdit, 
                             QTableWidget, QTableWidgetItem, QMessageBox, QHeaderView)

'''
Bu sınıf, hastane randevu sisteminin doktor paneli penceresini oluşturur.
Doktorlar, müsaitlik zamanları ekleyebilir ve randevularını görüntüleyebilir.
'''
class DoktorPaneli(QWidget):
    def __init__(self, doktor, sistem):
        super().__init__()
        self.doktor = doktor
        self.sistem = sistem
        self.setWindowTitle(f'{doktor.isim} - Doktor Paneli')
        self.setGeometry(100, 100, 1100, 700)
        self.initUI()
        self.show()

# pencerenin arayüzünü oluşturur
    def initUI(self):
        layout = QVBoxLayout()
        
        # Müsaitlik Zamanı Ekleme Alanı
        self.baslangic_tarih_secici = QDateTimeEdit(self)
        self.baslangic_tarih_secici.setCalendarPopup(True)
        self.bitis_tarih_secici = QDateTimeEdit(self)
        self.bitis_tarih_secici.setCalendarPopup(True)
        zaman_ekle_buton = QPushButton('Zaman Ekle', self)
        zaman_ekle_buton.clicked.connect(self.zaman_ekle)

        layout.addWidget(QLabel('Müsaitlik Zamanları Ekle'))
        layout.addWidget(self.baslangic_tarih_secici)
        layout.addWidget(self.bitis_tarih_secici)
        layout.addWidget(zaman_ekle_buton)

        # Tablolar için konteyner
        tablo_konteyner = QHBoxLayout()

        # Müsait Zamanlar Tablosu
        self.musait_zamanlar_tablo = QTableWidget(0, 2)
        self.musait_zamanlar_tablo.setHorizontalHeaderLabels(['Başlangıç Zamanı', 'Bitiş Zamanı'])
        self.musait_zamanlar_tablo.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)

        # Randevular Tablosu
        self.randevular_tablo = QTableWidget(0, 4)
        self.randevular_tablo.setHorizontalHeaderLabels(['Tarih', 'Hasta İsmi', 'Durum', 'Randevu ID'])
        self.randevular_tablo.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.setStyleSheet("""
            QWidget {
                font-family: Calibri;
                font-size: 25px;
                background-color: #09684d;
                color: white;
                border: 2px solid white; 
            }
            QLineEdit {
                background-color: white;
                color: black;
                border: 1px solid #ccc; 
            }
            QHeaderView::section {
                background-color: #0b9161;
                color: white;
                padding: 4px;
                border: 1px solid white; 
            }
            QPushButton {
                background-color: white;
                color: green;
                font-family: Calibri;
                font-size: 25px;
            }
        """)
        tablo_konteyner.addWidget(self.musait_zamanlar_tablo)
        tablo_konteyner.addWidget(self.randevular_tablo)
        layout.addLayout(tablo_konteyner)
        self.musait_zamanlari_goster()
        self.setLayout(layout)
        self.randevulari_goster()
        
# Müsaitlik zamanı ekler
    def zaman_ekle(self):
        baslangic = self.baslangic_tarih_secici.dateTime().toPyDateTime()
        bitis = self.bitis_tarih_secici.dateTime().toPyDateTime()
        if baslangic >= bitis:
            QMessageBox.warning(self, 'Hata', 'Başlangıç zamanı bitiş zamanından sonra olamaz.')
        else:
            self.doktor.musait_zaman_ekle(baslangic, bitis)
            self.musait_zamanlari_goster()

# doktora ait müsait zamanları gösterir
    def musait_zamanlari_goster(self):
        self.musait_zamanlar_tablo.clearContents()
        self.musait_zamanlar_tablo.setRowCount(0)
        for baslangic, bitis in self.doktor.musait_zamanlari_listele():
            row = self.musait_zamanlar_tablo.rowCount()
            self.musait_zamanlar_tablo.insertRow(row)
            self.musait_zamanlar_tablo.setItem(row, 0, QTableWidgetItem(str(baslangic)))
            self.musait_zamanlar_tablo.setItem(row, 1, QTableWidgetItem(str(bitis)))

        
# doktora ait randevuları gösterir
    def randevulari_goster(self):
        randevular = self.sistem.doktorRandevulari(self.doktor)
        for randevu in randevular:
            row = self.randevular_tablo.rowCount()
            self.randevular_tablo.insertRow(row)
            self.randevular_tablo.setItem(row, 0, QTableWidgetItem(randevu.tarih.strftime('%Y-%m-%d %H:%M')))
            self.randevular_tablo.setItem(row, 1, QTableWidgetItem(randevu.hasta.isim))
            self.randevular_tablo.setItem(row, 2, QTableWidgetItem(randevu.durum))
            self.randevular_tablo.setItem(row, 3, QTableWidgetItem(str(randevu.id)))
