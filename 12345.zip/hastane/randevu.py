'''
Bu modülde Randevu sınıfı tanımlanmıştır. Bu sınıf, bir randevunun özelliklerini ve işlemlerini tanımlar.
'''

class Randevu:
    def __init__(self, doktor, hasta, tarih, durum):
        self.doktor = doktor
        self.hasta = hasta
        self.tarih = tarih
        self.durum = durum  # 'geçmiş', 'iptal edilmiş', 'gelecek'
        self.id = id(self) # Her randevuya benzersiz bir kimlik vermek için id() fonksiyonunu kullanıyoruz

    
