
from PyQt5.QtCore import QDateTime

'''
Doktor sınıfı, hastane randevu sistemindeki doktorları temsil eder.
'''
class Doktor:
    def __init__(self, isim, tc, uzmanlik_alani):
        self.isim = isim
        self.tc = tc
        self.uzmanlik_alani = uzmanlik_alani
        self.musait_zamanlar = []  # Doktorun müsait olduğu zamanları tutacak liste

    def musait_zaman_ekle(self, baslangic_tarihi, bitis_tarihi):
        # Doktorun müsait zamanlar listesine yeni bir zaman aralığı ekler.
        self.musait_zamanlar.append((baslangic_tarihi, bitis_tarihi))

    def musait_zamanlari_listele(self):
        return self.musait_zamanlar
    
    def musaitMi(self, tarih):
        # Verilen tarih ve saatte doktorun müsait olup olmadığını kontrol eder.
        # eğer tarih geçmiş bir tarihse randevu eklenemez
        if tarih < QDateTime.currentDateTime():
            return False
        for baslangic, bitis in self.musait_zamanlar:
            if baslangic <= tarih < bitis:
                return True
        return False
        
