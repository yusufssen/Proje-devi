# Etkinlik sınıfı. Etkinlik bilgilerini tutar. Etkinlik adı, tarihi, yeri ve bilet fiyatı bilgilerini tutar.

class Etkinlik:
    def __init__(self, ad, tarih, yer, fiyat, toplam_bilet_sayisi, etkinlik_id=None):
        self.ad = ad
        self.tarih = tarih
        self.yer = yer
        self.fiyat = fiyat
        self.toplam_bilet_sayisi = toplam_bilet_sayisi
        self.kalan_bilet_sayisi = toplam_bilet_sayisi
        if etkinlik_id is None:
            self.etkinlik_id = id(self)
        else:
            self.etkinlik_id = etkinlik_id

    def __str__(self):
        return f"{self.ad} ({self.tarih})"
    
    def getAd(self):
        return self.ad
    
    def getTarih(self):
        return self.tarih
    
    def getYer(self):
        return self.yer
    
    def getFiyat(self):
        return self.fiyat
    
    def getEtkinlikId(self):
        return self.etkinlik_id
    
    def biletSat(self):
        if self.kalan_bilet_sayisi > 0:
            self.kalan_bilet_sayisi -= 1
            return True
        else:
            return False
        
    def kalanBiletSayisi(self):
        return self.kalan_bilet_sayisi
    
