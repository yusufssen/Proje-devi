# Katılımcı sınıfı. Katılımcı bilgilerini tutar. Ad, soyad, telefon ve e-posta bilgilerini tutar.

class Katilimci:
    def __init__(self, ad, soyad, telefon, eposta, katilimci_id=None):
        self.ad = ad
        self.soyad = soyad
        self.telefon = telefon
        self.eposta = eposta
        if katilimci_id is None:
            self.katilimci_id = id(self)
        else:
            self.katilimci_id = katilimci_id

    def __str__(self):
        return f"{self.ad} {self.soyad} \n{self.telefon} \n{self.eposta}"

    def getAd(self):
        return self.ad

    def getSoyad(self):
        return self.soyad

    def getTelefon(self):
        return self.telefon

    def getEposta(self):
        return self.eposta

    def getKatilimciId(self):
        return self.katilimci_id

