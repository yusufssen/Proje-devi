from Bilet import Bilet
from Etkinlik import Etkinlik
from Katilimci import Katilimci


class Sistem:
    
    def __init__(self):
        self.etkinlikler = {}
        self.katilimcilar = {}
        self.biletler = {}

    def etkinlikEkle(self, ad, tarih, yer, fiyat, toplam_bilet_sayisi):
        etkinlik = Etkinlik(ad, tarih, yer, fiyat, toplam_bilet_sayisi)
        self.etkinlikler[etkinlik.getEtkinlikId()] = etkinlik
        return etkinlik
    
        
    def etkinlikListele(self):
        return self.etkinlikler.values()
    
    def katilimciEkle(self, ad, soyad, telefon, eposta):
        katilimci = Katilimci(ad, soyad, telefon, eposta)
        self.katilimcilar[katilimci.getKatilimciId()] = katilimci
        return katilimci
    
    def katilimciSayisi(self, etkinlik_id):
        sayac = 0
        for bilet in self.biletler.values():
            if bilet.getEtkinlikId() == etkinlik_id:
                sayac += 1
        return sayac
    
    def biletSat(self, etkinlik_id, katilimci_id, adet=1):
        etkinlik = self.etkinlikler.get(etkinlik_id)
        if etkinlik is None:
            raise ValueError("Etkinlik bulunamadı")
        
        katilimci = self.katilimcilar.get(katilimci_id)
        if katilimci is None:
            raise ValueError("Katılımcı bulunamadı")
        
        if etkinlik.kalanBiletSayisi() >= adet:
            biletno_list = []
            for i in range(adet):
                    bilet = Bilet(etkinlik_id, katilimci, etkinlik.getFiyat())
                    biletno_list.append(bilet.getBiletNo())
                    self.biletler[bilet.getBiletNo()] = bilet
                    etkinlik.biletSat()
        else:
            raise ValueError("Bilet satışı yapılamadı, etkinlik dolu")
        return biletno_list
        
    
    def biletKontrol(self, bilet_no):
        bilet = self.biletler.get(int(bilet_no))
        
        if bilet is not None:
            return "\nBilet no: " + str(bilet_no) + "\nEtkinlik: " + self.etkinlikler[bilet.getEtkinlikId()].getAd() + "\nKatılımcı: " + str(bilet.getKatilimci())
        else:
            return None
    