# Bilet sınıfı. Etkinlik_id, katılımcı bilgileri, bilet fiyatı ve bilet numarası bilgilerini tutar.
# '''
class Bilet:
    bilet_id = 0
    def __init__(self, etkinlik_id, katilimci, fiyat, bilet_no=None):
        self.etkinlik_id = etkinlik_id
        self.katilimci = katilimci
        self.fiyat = fiyat
        if bilet_no is None:
            self.bilet_no = Bilet.bilet_id + 1
            Bilet.bilet_id += 1
        else:
            self.bilet_no = bilet_no
            
    

    def getKatilimci(self):
        return self.katilimci
    
    def getFiyat(self):
        return self.fiyat
    
    def getBiletNo(self):
        return self.bilet_no
    
    def getEtkinlikId(self):
        return self.etkinlik_id
    
    