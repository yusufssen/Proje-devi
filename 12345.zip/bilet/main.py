import sys
from PyQt5.QtWidgets import (QApplication, QHeaderView,QMessageBox, QMainWindow, QTabWidget, QWidget, QVBoxLayout, QPushButton, QLineEdit, QLabel,  QTableWidget, QTableWidgetItem, QDialog, QHBoxLayout, QFormLayout, QSpinBox)
from Sistem import Sistem
from PyQt5.QtGui import QIntValidator

'''
Bu kodda, PyQt5 kütüphanesi kullanılarak etkinlik yönetim sistemi oluşturulmuştur.
Sistem sınıfı içerisinde etkinlikler, katılımcılar ve biletler sözlüklerinde tutulmaktadır. 
Etkinlik sınıfı etkinlik bilgilerini tutar. Etkinlik adı, tarihi, yeri ve bilet fiyatı bilgilerini tutar.
Katılımcı sınıfı katılımcı bilgilerini tutar. Ad, soyad, telefon ve e-posta bilgilerini tutar.
Bilet sınıfı etkinlik_id, katılımcı bilgileri, bilet fiyatı ve bilet numarası bilgilerini tutar.
Sistem sınıfı içerisinde etkinlik ekleme, etkinlik listeleme, katılımcı ekleme, katılımcı sayısı, bilet satışı ve bilet kontrol işlemleri yapılmaktadır.
EtkinlikTablari sınıfı etkinliklerin listelendiği, etkinlik ekleme ve bilet kontrol işlemlerinin yapıldığı arayüzü oluşturur.
BiletAlDialog sınıfı bilet satın alma işlemlerinin yapıldığı arayüzü oluşturur.
EtkinlikSistemiGUI sınıfı ise tüm arayüzü oluşturur.
'''
class EtkinlikSistemiGUI(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle('Etkinlik Yönetim Sistemi')
        self.setGeometry(100, 100, 800, 600)
        self.sistem = Sistem()
        self.initUI()

    def initUI(self):
        self.tab_widget = EtkinlikTablari(self.sistem, self)
        self.setCentralWidget(self.tab_widget)

class EtkinlikTablari(QTabWidget):
    def __init__(self, sistem, parent=None):
        super().__init__(parent)
        self.sistem = sistem
        self.etkinlik_tab = QWidget()
        self.katilimci_tab = QWidget()
        self.bilet_tab = QWidget()

        self.addTab(self.etkinlik_tab, "Etkinlikler")
        self.addTab(self.katilimci_tab, "Etkinlik Ekle")
        self.addTab(self.bilet_tab, "Bilet Kontrol")

        self.etkinlikTabUI()
        self.katilimciTabUI()
        self.biletTabUI()

    def etkinlikTabUI(self):
        layout = QVBoxLayout()
        self.table = QTableWidget()
        self.table.setColumnCount(4)
        self.table.setHorizontalHeaderLabels(["Etkinlik Adı", "Tarih", "Yer", "Bilet Al"])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        layout.addWidget(self.table)
        self.etkinlik_tab.setLayout(layout)
        self.etkinlikleriYenile()

    def etkinlikleriYenile(self):
        self.table.setRowCount(0)
        etkinlikler = self.sistem.etkinlikListele()
        for etkinlik in etkinlikler:
            self.etkinlikSatiriEkle(etkinlik)

    def etkinlikSatiriEkle(self, etkinlik):
        row = self.table.rowCount()
        self.table.insertRow(row)
        self.table.setItem(row, 0, QTableWidgetItem(etkinlik.ad))
        self.table.setItem(row, 1, QTableWidgetItem(etkinlik.tarih))
        self.table.setItem(row, 2, QTableWidgetItem(etkinlik.yer))
        bilet_al_buton = QPushButton('Bilet Al')
        bilet_al_buton.clicked.connect(lambda *_: self.biletAl(etkinlik))
        self.table.setCellWidget(row, 3, bilet_al_buton)

    def biletAl(self, etkinlik):
        self.bilet_al_dialog = BiletAlDialog(etkinlik, self.sistem, self)
        self.bilet_al_dialog.show()

    def katilimciTabUI(self):
        layout = QFormLayout()
        self.etkinlik_adi = QLineEdit("Mor ve Ötesi Konser")
        self.etkinlik_tarihi = QLineEdit("12.12.2020 - 20:00")
        self.etkinlik_yeri = QLineEdit("İstanbul Harbiye Açıkhava")
        self.etkinlik_kapasitesi = QSpinBox()
        self.etkinlik_kapasitesi.setRange(1, 10000)
        self.etkinlik_fiyati = QSpinBox()
        self.etkinlik_fiyati.setRange(0, 10000)
        etkinlik_ekle_buton = QPushButton('Etkinlik Ekle')
        etkinlik_ekle_buton.clicked.connect(self.etkinlikEkle)

        layout.addRow("Etkinlik Adı:", self.etkinlik_adi)
        layout.addRow("Tarih:", self.etkinlik_tarihi)
        layout.addRow("Yer:", self.etkinlik_yeri)
        layout.addRow("Kapasite:", self.etkinlik_kapasitesi)
        layout.addRow("Fiyat:", self.etkinlik_fiyati)
        layout.addRow(etkinlik_ekle_buton)
        self.katilimci_tab.setLayout(layout)

    def etkinlikEkle(self):
        ad = self.etkinlik_adi.text()
        tarih = self.etkinlik_tarihi.text()
        yer = self.etkinlik_yeri.text()
        fiyat = self.etkinlik_fiyati.value()
        kapasite = self.etkinlik_kapasitesi.value()
        try:
            self.sistem.etkinlikEkle(ad, tarih, yer,  fiyat, kapasite)
            QMessageBox.information(self, "Etkinlik Eklendi", "Etkinlik başarıyla eklendi")
        except ValueError as e:
            QMessageBox.warning(self, "Etkinlik Eklenemedi", str(e))
        self.etkinlikleriYenile()

    def biletTabUI(self):
        layout = QVBoxLayout()
        self.bilet_no_giris = QLineEdit()
        self.bilet_no_giris.setValidator(QIntValidator())
        bilet_kontrol_buton = QPushButton('Bilet Kontrol Et')
        bilet_kontrol_buton.clicked.connect(self.biletKontrolEt)
        self.bilet_bilgisi = QLabel("")
        self.bilet_bilgisi.setStyleSheet("font-size: 20px; font-weight: bold;")

        layout.addWidget(QLabel("Bilet No:"))
        layout.addWidget(self.bilet_no_giris)
        layout.addWidget(bilet_kontrol_buton)
        layout.addWidget(self.bilet_bilgisi)
        layout.addStretch()
        self.bilet_tab.setLayout(layout)

    def biletKontrolEt(self):
        bilet_no = self.bilet_no_giris.text()
        bilet = self.sistem.biletKontrol(bilet_no)
        if bilet:
            self.bilet_bilgisi.setText(f"----Bilet Geçerli---- {bilet}")
        else:
            self.bilet_bilgisi.setText("Bilet Geçersiz")

class BiletAlDialog(QDialog):
    def __init__(self, etkinlik, sistem, parent=None):
        super().__init__(parent)
        self.etkinlik = etkinlik
        self.sistem = sistem
        self.initUI()

    def initUI(self):
        layout = QFormLayout()
        self.ad = QLineEdit("Ali")
        self.soyad = QLineEdit("Demir")
        self.telefon = QLineEdit("5555555555")
        self.eposta = QLineEdit("ali@demir.com")
        bilet_sayisi = QSpinBox()
        bilet_onay_buton = QPushButton('Bilet Onayla')
        bilet_onay_buton.clicked.connect(lambda: self.biletSatinal(bilet_sayisi.value()))

        layout.addRow("Ad:", self.ad)
        layout.addRow("Soyad:", self.soyad)
        layout.addRow("Telefon:", self.telefon)
        layout.addRow("Eposta:", self.eposta)
        layout.addRow("Bilet Sayısı:", bilet_sayisi)
        layout.addRow(bilet_onay_buton)
        self.setLayout(layout)

    def biletSatinal(self, sayi):
        katilimci = self.sistem.katilimciEkle(self.ad.text(), self.soyad.text(), self.telefon.text(), self.eposta.text())
        if sayi <= 0:
            QMessageBox.warning(self, "Bilet Satın Alınamadı", "Bilet sayısı 0'dan büyük olmalıdır.")
            return
        try:
            biletno_list=self.sistem.biletSat(self.etkinlik.getEtkinlikId(), katilimci.getKatilimciId(), sayi)
            QMessageBox.information(self, "Bilet Satın Alındı", "Toplam ücret: " + str(sayi * self.etkinlik.getFiyat())  + "TL\nBilet numaralarınız: " + ", ".join(map(str, biletno_list)) + "\nLütfen Saklayınız. "  )
        except ValueError as e:
            QMessageBox.warning(self, "Bilet Satın Alınamadı", str(e))
        self.accept()

if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = EtkinlikSistemiGUI()
    ex.show()
    sys.exit(app.exec_())
