from Kullanici import Kullanici
from Kurs import Kurs

class Egitmen(Kullanici):
    def __init__(self, isim, eposta, sifre, uzmanlik_alani):
        super().__init__(isim, eposta, sifre)
        self.uzmanlik_alani = uzmanlik_alani
        self.kurs_listesi = []

    def kurs_ac(self, kurs_adi, icerik, icerik_ozeti):
        yeni_kurs = Kurs(kurs_adi, self, icerik_ozeti, icerik, self.uzmanlik_alani)
        self.kurs_listesi.append(yeni_kurs)
        return yeni_kurs
