from Sistem import Sistem
from Ogrenci import Ogrenci
import sys
from PyQt5.QtCore import pyqtSlot 

from PyQt5.QtWidgets import (QApplication, QDialog, QTabWidget, QWidget, QVBoxLayout, QTableWidget, QTableWidgetItem, QPushButton, QMessageBox, QFormLayout, QLabel, QTextEdit, QScrollArea)

'''
bu sınıf öğrenci panelini oluşturur, öğrenci panelinde öğrenci kursları görüntüleyebilir ve kayıtlı kurslarına ulaşabilir
'''
class OgrenciPaneli(QDialog):
    def __init__(self, ogrenci, sistem):
        super().__init__()
        self.ogrenci = ogrenci
        self.sistem = sistem
        self.setWindowTitle('Öğrenci Paneli')
        self.setGeometry(100, 100, 600, 400)
        self.initUI()

    def initUI(self):
        self.tabs = QTabWidget()
        self.kurs_goruntule_tab = QWidget()
        self.kayitli_kurslar_tab = QWidget()

        self.tabs.addTab(self.kurs_goruntule_tab, "Kursları Görüntüle")
        self.tabs.addTab(self.kayitli_kurslar_tab, "Kayıtlı Kurslarım")

        self.kurslariGoruntuleTabUI()
        self.kayitliKurslarTabUI()

        main_layout = QVBoxLayout()
        main_layout.addWidget(self.tabs)
        self.setLayout(main_layout)
# Kursları görüntüleme tabını oluşturur
    def kurslariGoruntuleTabUI(self):
        layout = QVBoxLayout()
        self.kurs_table = QTableWidget()
        self.kurs_table.setColumnCount(4)
        self.kurs_table.setHorizontalHeaderLabels(["Kurs Adı", "Eğitmen", "Alan", "Detay"])
        self.kurslariYenile()

        layout.addWidget(self.kurs_table)
        self.kurs_goruntule_tab.setLayout(layout)

    def kurslariYenile(self):
        self.kurs_table.setRowCount(0)
        for kurs in self.sistem.kurslar:
            row_position = self.kurs_table.rowCount()
            self.kurs_table.insertRow(row_position)
            self.kurs_table.setItem(row_position, 0, QTableWidgetItem(kurs.ad))
            self.kurs_table.setItem(row_position, 1, QTableWidgetItem(kurs.egitmen.isim))
            self.kurs_table.setItem(row_position, 2, QTableWidgetItem(kurs.alan))
            detay_buton = QPushButton('Detaylar')
            detay_buton.clicked.connect(lambda *_: self.kursDetayGoster(kurs))
            self.kurs_table.setCellWidget(row_position, 3, detay_buton)

    # Kurs detaylarını gösteren pencere
    def kursDetayGoster(self, kurs):
        detay_penceresi = QDialog(self)
        detay_penceresi.setWindowTitle('Kurs Detayları')
        layout = QFormLayout()
        layout.addRow("Kurs Adı:", QLabel(kurs.ad))
        layout.addRow("Eğitmen:", QLabel(kurs.egitmen.isim))
        layout.addRow("Özet:", QLabel(kurs.icerik_ozeti))
        kaydol_buton = QPushButton('Kaydol')
        kaydol_buton.clicked.connect(lambda: self.kursaKaydol(kurs))
        layout.addRow(kaydol_buton)
        detay_penceresi.setLayout(layout)
        detay_penceresi.exec_()


    def kursaKaydol(self, kurs):
        try:
            self.ogrenci.kursa_kaydol(kurs)
            self.kayitliKurslarYenile()
            QMessageBox.information(self, "Başarılı", "Kursa başarıyla kaydoldunuz.")
        except ValueError as e:
            QMessageBox.critical(self, "Hata", str(e))
        
# Kayıtlı kurslar tabını oluşturur
    def kayitliKurslarTabUI(self):
        layout = QVBoxLayout()
        self.kayitli_kurs_table = QTableWidget()
        self.kayitli_kurs_table.setColumnCount(3)
        self.kayitli_kurs_table.setHorizontalHeaderLabels(["Kurs Adı", "Eğitmen", "Kursa Git"])
        self.kayitliKurslarYenile()

        layout.addWidget(self.kayitli_kurs_table)
        self.kayitli_kurslar_tab.setLayout(layout)

    def kayitliKurslarYenile(self):
        self.kayitli_kurs_table.setRowCount(0)
        for kurs in self.ogrenci.kayitli_kurslar:
            row_position = self.kayitli_kurs_table.rowCount()
            self.kayitli_kurs_table.insertRow(row_position)
            self.kayitli_kurs_table.setItem(row_position, 0, QTableWidgetItem(kurs.ad))
            self.kayitli_kurs_table.setItem(row_position, 1, QTableWidgetItem(kurs.egitmen.isim))
            kursa_git_buton = QPushButton('Kursa Git')
            kursa_git_buton.clicked.connect(lambda *_: self.kursIcerikGoster(kurs))
            self.kayitli_kurs_table.setCellWidget(row_position, 2, kursa_git_buton)

# Kurs içeriğini gösteren pencere
    def kursIcerikGoster(self, kurs):
        icerik_penceresi = QDialog(self)
        icerik_penceresi.setWindowTitle('Kurs İçeriği')
        icerik_penceresi.setMinimumSize(700, 500)

        scroll_area = QScrollArea(icerik_penceresi) 
        scroll_area.setWidgetResizable(True)
        content_widget = QWidget() 
        layout = QVBoxLayout(content_widget)

        # Kurs adı ve eğitmeni
        kurs_bilgisi = f"{kurs.ad} - {kurs.egitmen.isim}"
        kurs_bilgisi_label = QLabel(kurs_bilgisi)
        kurs_bilgisi_label.setStyleSheet("font-weight: bold; font-size: 16px;")
        layout.addWidget(kurs_bilgisi_label)

        # Kurs özeti
        ozet_label = QLabel("<b>İçerik Özeti:</b> " + kurs.icerik_ozeti)
        layout.addWidget(ozet_label)

        # Kurs içeriği
        icerik_label = QLabel("<b>Kurs İçeriği:</b>")
        layout.addWidget(icerik_label)
        kurs_icerik_text = QTextEdit()
        kurs_icerik_text.setReadOnly(True)
        kurs_icerik_text.setHtml(kurs.icerik)
        layout.addWidget(kurs_icerik_text)

        # Kurs materyalleri
        materyal_label = QLabel("<b>Materyaller:</b>")
        layout.addWidget(materyal_label)
        for materyal in kurs.ders_materyalleri:
            materyal_label = QLabel(materyal)
            layout.addWidget(materyal_label)

        scroll_area.setWidget(content_widget)  
        main_layout = QVBoxLayout(icerik_penceresi)
        main_layout.addWidget(scroll_area)
        icerik_penceresi.setLayout(main_layout)
        icerik_penceresi.exec_()

if __name__ == '__main__':

    app = QApplication(sys.argv)
    sistem = Sistem()
    ogrenci = Ogrenci("Öğrenci Adı", "email@email.com", "sifre")
    ex = OgrenciPaneli(ogrenci, sistem)
    ex.show()
    sys.exit(app.exec_())
