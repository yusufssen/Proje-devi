from Kullanici import Kullanici
from Kurs import Kurs

class Ogrenci(Kullanici):
    def __init__(self, isim, eposta, sifre):
        super().__init__(isim, eposta, sifre)
        self.kayitli_kurslar = []

    def kursa_kaydol(self, kurs):
        if kurs in self.kayitli_kurslar:
            raise ValueError("Bu kursa zaten kayıtlısınız")
        kurs.kaydol(self)
        self.kayitli_kurslar.append(kurs)