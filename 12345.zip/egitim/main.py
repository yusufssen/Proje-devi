import sys
from Sistem import Sistem
from Ogrenci import Ogrenci
from Egitmen import Egitmen
from EgitmenGUI import EgitmenPaneli
from OgrenciGUI import OgrenciPaneli

from PyQt5.QtWidgets import (QApplication, QMainWindow, QWidget, QMessageBox, QHBoxLayout, QFormLayout, QLabel, QLineEdit, QRadioButton, QPushButton, QGroupBox, QComboBox)

class EgitimSistemiGUI(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle('Online Eğitim Platformu')
        self.setGeometry(100, 100, 400, 300)
        self.sistem = Sistem()
        self.initUI()

    def initUI(self):
        # Ana düzen
        layout = QHBoxLayout()

        # Kayıt formu
        self.kayit_grup = QGroupBox("Kayıt Ol")
        kayit_duzen = QFormLayout()
        self.rol_combo = QComboBox()
        self.rol_combo.addItems([ "Eğitmen","Öğrenci"])
        self.rol_combo.currentIndexChanged.connect(self.uzmanlik_alani_goster)
        self.isim_girdi = QLineEdit()
        self.eposta_girdi = QLineEdit()
        self.sifre_girdi = QLineEdit()
        self.uzmanlik_girdi = QLineEdit()
        self.kayit_butonu = QPushButton('Kayıt Ol')
        self.kayit_butonu.clicked.connect(self.kullanici_kaydet)

        kayit_duzen.addRow("Rol:", self.rol_combo)
        kayit_duzen.addRow("İsim:", self.isim_girdi)
        kayit_duzen.addRow("Eposta:", self.eposta_girdi)
        kayit_duzen.addRow("Şifre:", self.sifre_girdi)
        kayit_duzen.addRow("Uzmanlık Alanı:", self.uzmanlik_girdi)
        
        kayit_duzen.addRow(self.kayit_butonu)
        self.kayit_grup.setLayout(kayit_duzen)

        # Giriş formu
        self.giris_grup = QGroupBox("Giriş Yap")
        giris_duzen = QFormLayout()
        self.giris_eposta_girdi = QLineEdit()
        self.giris_sifre_girdi = QLineEdit()
        self.giris_butonu = QPushButton('Giriş Yap')
        self.giris_butonu.clicked.connect(self.giris)

        giris_duzen.addRow("Eposta:", self.giris_eposta_girdi)
        giris_duzen.addRow("Şifre:", self.giris_sifre_girdi)
        giris_duzen.addRow(self.giris_butonu)
        self.giris_grup.setLayout(giris_duzen)

        # Ana düzene ekle
        layout.addWidget(self.kayit_grup)
        layout.addWidget(self.giris_grup)

        # Ana bileşen
        merkezi_bilesen = QWidget()
        merkezi_bilesen.setLayout(layout)
        self.setCentralWidget(merkezi_bilesen)

    def uzmanlik_alani_goster(self, index):
        self.uzmanlik_girdi.setVisible(index == 0)  # 'Eğitmen' seçildiyse göster

    def kullanici_kaydet(self):
        rol = self.rol_combo.currentText()
        isim = self.isim_girdi.text()
        eposta = self.eposta_girdi.text()
        sifre = self.sifre_girdi.text()
        uzmanlik = self.uzmanlik_girdi.text() if rol == "Eğitmen" else ""

        if rol == "Eğitmen" and isim and eposta and sifre and uzmanlik:
            kullanici = Egitmen(isim, eposta, sifre, uzmanlik)
        elif rol == "Öğrenci" and isim and eposta and sifre:
            kullanici = Ogrenci(isim, eposta, sifre)
        else:
            QMessageBox.critical(self, 'Hata', 'Eksik bilgi girdiniz')
            return
        try:
            self.sistem.kullanici_ekle(kullanici)
            QMessageBox.information(self, 'Kayıt Başarılı', f"{kullanici.isim} olarak kayıt oldunuz")
        except ValueError as hata:
            QMessageBox.critical(self, 'Hata', str(hata))


    def giris(self):
        eposta = self.giris_eposta_girdi.text()
        sifre = self.giris_sifre_girdi.text()
        try:
            kullanici = self.sistem.giris_yap(eposta, sifre)
            if kullanici:
                QMessageBox.information(self, 'Giriş Başarılı', f"{kullanici.isim} olarak giriş yaptınız")
                if isinstance(kullanici, Egitmen):
                    self.egitmen_paneli = EgitmenPaneli(kullanici, self.sistem)
                    self.egitmen_paneli.show()
                elif isinstance(kullanici, Ogrenci):
                    self.ogrenci_paneli = OgrenciPaneli(kullanici, self.sistem)
                    self.ogrenci_paneli.show()
            else:
                QMessageBox.critical(self, 'Hata', 'Eposta veya şifre hatalı')
        except ValueError as hata:
            QMessageBox.critical(self, 'Hata', str(hata))



if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = EgitimSistemiGUI()
    ex.show()
    sys.exit(app.exec_())
