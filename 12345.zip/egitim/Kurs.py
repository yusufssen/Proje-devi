class Kurs:
    def __init__(self, ad, egitmen, icerik_ozeti, icerik, alan):
        self.ad = ad
        self.egitmen = egitmen
        self.icerik_ozeti = icerik_ozeti
        self.icerik = icerik
        self.alan = alan
        self.ders_materyalleri = []
        self.kayitli_ogrenciler = []

    def kaydol(self, ogrenci):
        if ogrenci not in self.kayitli_ogrenciler:
            self.kayitli_ogrenciler.append(ogrenci)

    def materyal_yukle(self, materyal):
        self.ders_materyalleri.append(materyal)