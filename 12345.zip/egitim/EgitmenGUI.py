import sys
from Sistem import  Sistem 
from Egitmen import Egitmen

from PyQt5.QtWidgets import (QApplication, QTextEdit,QDialog, QTabWidget, QWidget, QVBoxLayout, QFormLayout,QHeaderView, QLineEdit, QPushButton, QLabel, QTableWidget, QTableWidgetItem, QMessageBox)

'''
bu sınıf eğitmen panelini oluşturur, eğitmen panelinde eğitmen kursları görüntüleyebilir ve yeni kurs ekleyebilir
kurslara materyal ekleyebilir
'''
class EgitmenPaneli(QDialog):
    def __init__(self, egitmen, sistem):
        super().__init__()
        self.egitmen = egitmen
        self.sistem = sistem
        self.setWindowTitle('Eğitmen Paneli')
        self.setGeometry(100, 100, 500, 300)
        self.initUI()

    def initUI(self):
        self.tabs = QTabWidget()
        self.tab1 = QWidget()
        self.tab2 = QWidget()

        self.tabs.addTab(self.tab1, "Yeni Kurs Ekle")
        self.tabs.addTab(self.tab2, "Mevcut Kurslar")

        self.kursTablosuOlustur()
        self.kurslariGoruntuleTablosu()

        ana_layout = QVBoxLayout()
        ana_layout.addWidget(self.tabs)
        self.setLayout(ana_layout)

    def kursTablosuOlustur(self):
        layout = QFormLayout()
        self.kurs_adi = QLineEdit()
        self.icerik_ozeti = QLineEdit()
        self.kurs_icerigi = QTextEdit()  # Kurs içeriği için zengin metin düzenleyici
        self.ekle_dugmesi = QPushButton('Kurs Ekle')
        self.ekle_dugmesi.clicked.connect(self.kursEkle)

        layout.addRow("Kurs Adı:", self.kurs_adi)
        layout.addRow("İçerik Özeti:", self.icerik_ozeti)
        layout.addRow("Kurs İçeriği:", self.kurs_icerigi)

        layout.addRow(self.ekle_dugmesi)

        self.tab1.setLayout(layout)

    def kurslariGoruntuleTablosu(self):
        layout = QVBoxLayout()
        self.kurs_tablosu = QTableWidget()
        self.kurs_tablosu.setColumnCount(3)
        self.kurs_tablosu.setHorizontalHeaderLabels([ "Kurs Adı", "İçerik Özeti", "Materyal Ekle"])
        self.kurs_tablosu.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.kursTablosunuGuncelle()

        layout.addWidget(self.kurs_tablosu)
        self.tab2.setLayout(layout)

    def kursEkle(self):
        kurs_adi = self.kurs_adi.text()
        icerik_ozeti = self.icerik_ozeti.text()
        icerik= self.kurs_icerigi.toPlainText()
        if kurs_adi and icerik_ozeti:
            yeni_kurs = self.egitmen.kurs_ac(kurs_adi,icerik, icerik_ozeti)
            self.sistem.kurslar.append(yeni_kurs)
            self.kursTablosunuGuncelle()
            QMessageBox.information(self, 'Başarılı', 'Kurs başarıyla eklendi')
        else:
            QMessageBox.critical(self, 'Hata', 'Kurs adı ve içerik özeti gerekli')

    def kursTablosunuGuncelle(self):
        self.kurs_tablosu.setRowCount(0)
        for kurs in self.egitmen.kurs_listesi:
            satir_pozisyonu = self.kurs_tablosu.rowCount()
            self.kurs_tablosu.insertRow(satir_pozisyonu)
            self.kurs_tablosu.setItem(satir_pozisyonu, 0, QTableWidgetItem(kurs.ad))
            self.kurs_tablosu.setItem(satir_pozisyonu, 1, QTableWidgetItem(kurs.icerik_ozeti))
            materyal_ekle_buton = QPushButton('Materyal Ekle')
            materyal_ekle_buton.clicked.connect(lambda _, kurs=kurs: self.materyalEkle(kurs))
            self.kurs_tablosu.setCellWidget(satir_pozisyonu, 2, materyal_ekle_buton)

    def materyalEkle(self, kurs):
        materyal_penceresi = QDialog(self)
        materyal_penceresi.setWindowTitle('Materyal Ekle')
        layout = QVBoxLayout()
        materyal_icerigi = QTextEdit()
        materyal_icerigi.setPlaceholderText('Materyal İçeriği')
        ekle_buton = QPushButton('Ekle')
        ekle_buton.clicked.connect(lambda: self.materyalEkleOnayla(kurs,  materyal_icerigi, materyal_penceresi))
        layout.addWidget(materyal_icerigi)
        layout.addWidget(ekle_buton)
        materyal_penceresi.setLayout(layout)
        materyal_penceresi.exec_()

    def materyalEkleOnayla(self, kurs, materyal_icerigi, pencere):
        icerik = materyal_icerigi.toPlainText()
        if icerik:
            kurs.materyal_yukle( icerik)
            self.kursTablosunuGuncelle()
            QMessageBox.information(self, 'Başarılı', 'Materyal başarıyla eklendi')
            pencere.close()
        else:
            QMessageBox.critical(self, 'Hata', 'Materyal adı ve içeriği gerekli')




    


if __name__ == '__main__':
    app = QApplication(sys.argv)
    sistem = Sistem()
    egitmen = Egitmen("Ali Demir", "egitmen@ornek.com", "parola", "Programlama")
    ex = EgitmenPaneli(egitmen, sistem)
    ex.show()
    sys.exit(app.exec_())
