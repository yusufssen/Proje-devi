from Ogrenci import Ogrenci
from Egitmen import Egitmen
from Kurs import Kurs

class Sistem:
    def __init__(self):
        self.kullanicilar = {}
        self.kurslar = []

    def kullanici_ekle(self, kullanici):
        if kullanici.eposta not in self.kullanicilar:
            self.kullanicilar[kullanici.eposta] = kullanici
        else:
            raise ValueError("Bu eposta adresi zaten kullanımda")

    def giris_yap(self, eposta, sifre):
        kullanici = self.kullanicilar.get(eposta)
        if kullanici and kullanici.sifre == sifre:
            return kullanici
        return None
    
    def kurs_ekle(self, kurs, egitmen):
        egitmen.kurs_listesi.append(kurs)
        self.kurslar.append(kurs)

    def kurs_kaydol(self, kurs, ogrenci):
        kurs.kaydol(ogrenci)
        ogrenci.kayitli_kurslar.append(kurs)


