class Kullanici:
    def __init__(self, isim, eposta, sifre):
        self.isim = isim
        self.eposta = eposta
        self.sifre = sifre