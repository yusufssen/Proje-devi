class Odunc:
    def __init__(self, kitap_id, uye_id):
        self.kitap_id = kitap_id
        self.uye_id = uye_id
        self.odunc_durumu = "ödünç alındı"

    def iade_et(self):
        self.odunc_durumu = "iade edildi"
    