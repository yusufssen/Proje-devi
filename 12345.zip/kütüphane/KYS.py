from PyQt5.QtWidgets import QMessageBox

class KYS:
    def __init__(self):
        self.kitaplar = {}
        self.uyeler = {}
        self.oduncler = {}

    def kitap_ekle(self, kitap):
        self.kitaplar[kitap.kitap_id] = kitap

    def uye_ekle(self, uye):
        self.uyeler[uye.uye_id] = uye

    def odunc_ekle(self, uye_id, odunc):
        if uye_id  in self.oduncler and self.oduncler[uye_id].odunc_durumu == "ödünç alındı":
            raise ValueError('Üye zaten ödünç kitap almış')
        elif  self.kitaplar[odunc.kitap_id].bosta_kopya == 0:
            raise ValueError('Kitap kopyası kalmadı')
        self.oduncler[uye_id] = odunc
        self.kitaplar[odunc.kitap_id].bosta_kopya -= 1

        return

    def odunc_iade(self, uye_id):
        if uye_id in self.oduncler:
            self.oduncler[uye_id].iade_et()
            self.kitaplar[self.oduncler[uye_id].kitap_id].bosta_kopya += 1
            


    def oduncleri_getir(self, uye_id):
        if uye_id in self.oduncler:
            return self.oduncler[uye_id]
        return None
    


    def uye_odunc(self):
        odunc_listesi = []
        for uye_id, odunc in self.oduncler.items():
            kitap = self.kitaplar[odunc.kitap_id]
            uye = self.uyeler[uye_id]
            odunc_listesi.append((uye_id, uye.isim, kitap.ad, odunc.odunc_durumu))
        return odunc_listesi