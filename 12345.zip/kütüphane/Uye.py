
class Uye:
    def __init__(self, isim, tel, uye_id=None):
        if uye_id is None:
           self.uye_id = id(self)
        else:
            self.uye_id = uye_id
        self.isim = isim
        self.tel = tel


    def getIsim(self):
        return self.isim