import sys
from PyQt5.QtWidgets import QApplication, QMainWindow, QTabWidget, QWidget, QVBoxLayout, QPushButton, QLineEdit, QLabel, QGridLayout, QTableWidget, QTableWidgetItem, QHeaderView, QDialog, QHBoxLayout,QMessageBox
from PyQt5.QtGui import QIntValidator
from Kitap import Kitap
from Uye import Uye
from Odunc import Odunc
from KYS import KYS


'''
Bu sınıf, kitaplar, üyeler ve ödünçlerin görüntülendiği bir pencere oluşturur.
Kitaplar sekmesinde kitaplar tablosu ve her kitap için ödünç al butonu bulunur.
Üyeler sekmesinde üye ekleme alanı bulunur.
Ödünçler sekmesinde ödünçler tablosu ve her ödünç için iade et butonu bulunur.
Bir üye aynı anda birden fazla kitap ödünç alamaz.
'''
class LibraryGUI(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle('Kütüphane Yönetim Sistemi')
        self.setGeometry(100, 100, 800, 600)
        self.kys = KYS()
        self.kitaplar()
        self.uyeler()
        self.initUI()

    def initUI(self):
        self.table_widget = LibraryTabs(self.kys, self)
        self.setCentralWidget(self.table_widget)
 

    def kitaplar(self):
        self.kys.kitap_ekle( Kitap("1", "Python Programlama", "Guido van Rossum", 3))
        self.kys.kitap_ekle( Kitap("2", "Java Programlama", "James Gosling", 2))
        self.kys.kitap_ekle( Kitap("3", "C Programlama", "Dennis Ritchie", 1))
        self.kys.kitap_ekle( Kitap("4", "C++ Programlama", "Bjarne Stroustrup", 0))

    def uyeler(self):
        self.kys.uye_ekle( Uye( "Ali", "123456789", 1))
        self.kys.uye_ekle( Uye( "Veli", "987654321", 2))
        self.kys.uye_ekle( Uye( "Ayşe", "543216789", 3))
        self.kys.uye_ekle( Uye( "Fatma", "987612345", 4))
'''
Bu sınıf kütüphane tablarını oluşturur.
'''
class LibraryTabs(QTabWidget):
    def __init__(self, kys, parent=None):
        super().__init__(parent)
        self.kys = kys
        self.tab1 = QWidget()
        self.tab2 = QWidget()
        self.tab3 = QWidget()

        self.addTab(self.tab1, "Kitaplar")
        self.addTab(self.tab2, "Üyeler")
        self.addTab(self.tab3, "Ödünçler")

        self.tab1UI()
        self.tab2UI()
        self.tab3UI()

    '''
    Bu sınıf kitaplar sekmesini oluşturur.
    Kitaplar tablosu ve her kitap için ödünç al butonu bulunur.
    '''
    def tab1UI(self):
        layout = QVBoxLayout()
        self.table = QTableWidget()
        self.table.setColumnCount(4)
        self.table.setHorizontalHeaderLabels(["Kitap ID", "Kitap Adı", "Yazar", "Kopya Sayısı", "İşlem"])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        layout.addWidget(self.table)
        self.tab1.setLayout(layout)
        self.kitaplariDoldur()

    def kitaplariDoldur(self):
        for kitap in self.kys.kitaplar.values():
            self.kitapSatir(kitap)


    def kitapSatir(self, kitap):
        row = self.table.rowCount()
        self.table.insertRow(row)
        self.table.setItem(row, 0, QTableWidgetItem(kitap.kitap_id))
        self.table.setItem(row, 1, QTableWidgetItem(kitap.ad))
        self.table.setItem(row, 2, QTableWidgetItem(kitap.yazar))
        self.table.setItem(row, 3, QTableWidgetItem(str(kitap.bosta_kopya)))

        btn = QPushButton('Ödünç Al')
        btn.clicked.connect(lambda *_: self.kitap_odunc(kitap.kitap_id))
        self.table.setCellWidget(row, 3, btn)

    def kitap_odunc(self, kitap_id):
        self.odunc_dialog = LoanDialog(kitap_id, self.kys, self)
        self.odunc_dialog.show()
        # dialog kapatıldığında ödünç tablosunu güncelle
        self.odunc_dialog.accepted.connect(self.oduncleriDoldur)
         
    '''
    Bu sınıf üyeler sekmesini oluşturur.
    Üye ekleme alanı bulunur.
    '''
    def tab2UI(self):
        layout = QGridLayout()
        self.isim_input = QLineEdit()
        self.phone_input = QLineEdit()
        self.phone_input.setValidator(QIntValidator())
        self.add_button = QPushButton('Üye Ekle')
        self.add_button.clicked.connect(self.uyeEkle)
        
        # Yazıları büyük yap
        font = self.isim_input.font()
        font.setPointSize(17)
        font.family='Calibri'

        self.isim_input.setFont(font)
        self.phone_input.setFont(font)
        self.add_button.setFont(font)

        isim_label = QLabel('İsim:')
        phone_label = QLabel('Telefon:')
        isim_label.setFont(font)
        phone_label.setFont(font)
        layout.addWidget(isim_label, 0, 0)
        layout.addWidget(self.isim_input, 0, 1)
        layout.addWidget(phone_label, 1, 0)
        layout.addWidget(self.phone_input, 1, 1)
        layout.addWidget(self.add_button, 2, 0, 1, 2)

        self.tab2.setLayout(layout)

    def uyeEkle(self):
        isim= self.isim_input.text()
        phone = self.phone_input.text()
        yeni_uye = Uye( isim, phone) 
        self.kys.uye_ekle(yeni_uye)
        self.uye_dialog= QMessageBox.information(self,"Üye Eklendi", "Üye no: " + str(yeni_uye.uye_id))
        print(yeni_uye.uye_id)


    '''
    Bu sınıf ödünçler sekmesini oluşturur.
    Ödünçler tablosu ve her ödünç için iade et butonu bulunur.
    '''
    def tab3UI(self):
        layout = QVBoxLayout()
        self.table = QTableWidget()
        self.table.setColumnCount(4)
        self.table.setHorizontalHeaderLabels(["Üye", "Kitap", "Durum", "İşlem"])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        layout.addWidget(self.table)
        self.oduncleriDoldur()
        self.tab3.setLayout(layout)

    def oduncleriDoldur(self):
        self.table.setRowCount(0)
        for uye_id, ad, yazar, durum in self.kys.uye_odunc():
            self.oduncSatir(uye_id, ad, yazar, durum)
    
    def oduncSatir(self,uye_id, ad, yazar, durum):
        row = self.table.rowCount()
        self.table.insertRow(row)
        self.table.setItem(row, 0, QTableWidgetItem(ad))
        self.table.setItem(row, 1, QTableWidgetItem(yazar))
        self.table.setItem(row, 2, QTableWidgetItem(durum))
        btn = QPushButton('İade Et')
        self.table.setCellWidget(row, 3, btn)
        btn.clicked.connect(lambda *_: self.kitap_iade(uye_id))


    def kitap_iade(self, uye_id):
        self.kys.odunc_iade(uye_id)
        self.oduncleriDoldur()  





'''
Bu sınıf ödünç verme işlemi için bir pencere oluşturur.
ekranın alt kısmında bir üye no giriş alanı ve onayla butonu bulunur.
eğer üye bulunamazsa, üye zaten ödünç almışsa veya kitap kopyası kalmamışsa hata mesajı gösterilir.
'''
class LoanDialog(QDialog):
    def __init__(self, kitap_id, kys, parent=None):
        super().__init__(parent)
        self.kitap_id = kitap_id
        self.kys = kys
        self.initUI()

    def initUI(self):
        layout = QHBoxLayout()
        self.uye_id_input = QLineEdit()
        self.uye_id_input.setValidator(QIntValidator())
        self.uye_id_input.setText("1")
        self.onayla_btn = QPushButton('Onayla')
        self.onayla_btn.clicked.connect(self.oduncIslemi)

        layout.addWidget(QLabel("Üye no:"))
        layout.addWidget(self.uye_id_input)
        layout.addWidget(self.onayla_btn)
        self.setLayout(layout)

    def oduncIslemi(self):
        uye_id = int(self.uye_id_input.text())
        if uye_id not in self.kys.uyeler:
            QMessageBox.warning(self, 'Hata', 'Üye bulunamadı')
            return
        odunc=Odunc(self.kitap_id, uye_id) 

        try:
            self.kys.odunc_ekle( uye_id,odunc)
            QMessageBox.information(self, 'Başarılı', 'Kitap <b>' +self.kys.uyeler[uye_id].getIsim() + '</b> adlı üyeye ödünç verildi')
        except ValueError as e:
            QMessageBox.warning(self, 'Hata', str(e))
        self.accept()



if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = LibraryGUI()
    ex.show()
    sys.exit(app.exec_())
