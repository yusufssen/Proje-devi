import uuid


class Kitap:
    def __init__(self,ISBN, ad, yazar, toplam_kopya):
        self.kitap_id = ISBN
        self.ad = ad
        self.yazar = yazar
        self.toplam_kopya = toplam_kopya
        self.bosta_kopya = toplam_kopya
        self.oduncler = []

    def __str__(self):
        return f"{self.ad} by {self.yazar}, Copies Available: {self.bosta_kopya}/{self.toplam_kopya}"

    def kitap_odunc_al(self, uye_id):
        if self.bosta_kopya > 0:
            self.oduncler.append(uye_id)
            self.bosta_kopya -= 1
        else:
            print("No copies available for loan.")

    def kitap_iade_et(self, uye_id):
        if uye_id in self.oduncler:
            self.oduncler.remove(uye_id)
            self.bosta_kopya += 1
