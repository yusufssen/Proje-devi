'''
Müşteri sınıfı
'''
class Musteri:
    def __init__(self, ad, telefon, kimlik_no):
        self.ad = ad
        self.telefon = telefon
        self.kimlik_no = kimlik_no
