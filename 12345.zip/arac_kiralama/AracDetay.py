from PyQt5.QtWidgets import QWidget, QVBoxLayout, QApplication, QLabel, QPushButton, QMessageBox, QTableWidget, QTableWidgetItem
from PyQt5.QtCore import pyqtSignal, QDateTime
from datetime import datetime
from PyQt5.QtWidgets import QDialog
from PyQt5.QtCore import Qt

'''
bu sınıf, araç kiralama sisteminin detay penceresini oluşturur.
içinde güncel kiralama bilgileri ve geçmiş kiralama bilgileri bulunmaktadır.
'''
class DetayPenceresi(QWidget):
    kiralamaSonlandi = pyqtSignal() # kiralama sonlandığında sinyal göndermek için

    def __init__(self, arac, kiralama_sistemi, parent=None):
        super().__init__(parent)
        self.setWindowFlags(Qt.Window)  # Pencere bayraklarını ayarla
        self.arac = arac
        self.kiralama_sistemi = kiralama_sistemi
        self.initUI()
        self.pencereyiOrtala()

# pencerenin arayüzünü oluşturur
    def initUI(self):
        layout = QVBoxLayout()

        self.kiralamaTablosu = QTableWidget(0, 6)
        self.kiralamaTablosu.setHorizontalHeaderLabels(['Başlangıç Tarihi', 'Müşteri Adı', 'Tel', 'TC', 'Bitiş Tarihi', 'Ücret'])
        self.kiralamaTablosu.setColumnWidth(0, 150)
        self.kiralamaTablosu.setColumnWidth(1, 100)
        self.kiralamaTablosu.setColumnWidth(2, 100)
        self.kiralamaTablosu.setColumnWidth(3, 100)
        self.kiralamaTablosu.setColumnWidth(4, 150)
        self.kiralamaTablosu.setColumnWidth(5, 80)
        self.resize(800, 600) 

        layout.addWidget(self.kiralamaTablosu)

        self.kiralamaTablosunuGuncelle()

        self.guncelKiralamaDetaylari = QLabel()
        layout.addWidget(self.guncelKiralamaDetaylari)

        # Eğer araç kiralanmışsa, kiralama bilgilerini göster
        if self.arac.kiralik:
            self.guncelKiralamaDetaylariGuncelle()
            kiralamaSonlandirButonu = QPushButton('Kiralama Sonlandır')
            kiralamaSonlandirButonu.clicked.connect(self.kiralamaSonlandir)
            layout.addWidget(kiralamaSonlandirButonu)

        self.setLayout(layout)

    def pencereyiOrtala(self):
        qr = self.frameGeometry()
        cp = QApplication.desktop().availableGeometry().center()
        qr.moveCenter(cp)
        self.move(qr.topLeft())
    # kiralama geçmişini günceller
    def kiralamaTablosunuGuncelle(self):
        self.kiralamaTablosu.setRowCount(0)
        for kiralama in reversed(self.arac.gecmis_kiralamalar):
            row = self.kiralamaTablosu.rowCount()
            self.kiralamaTablosu.insertRow(row)
            self.kiralamaTablosu.setItem(row, 0, QTableWidgetItem(kiralama['baslangic_tarihi'].strftime("%Y-%m-%d %H:%M")))
            self.kiralamaTablosu.setItem(row, 1, QTableWidgetItem(kiralama['musteri'].ad))
            self.kiralamaTablosu.setItem(row, 2, QTableWidgetItem(kiralama['musteri'].telefon))
            self.kiralamaTablosu.setItem(row, 3, QTableWidgetItem(kiralama['musteri'].kimlik_no))
            self.kiralamaTablosu.setItem(row, 4, QTableWidgetItem(kiralama['bitis_tarihi'].strftime("%Y-%m-%d %H:%M") if kiralama['bitis_tarihi'] else ""))
            self.kiralamaTablosu.setItem(row, 5, QTableWidgetItem(f"{kiralama['ucret']:.2f} TL"))

    # güncel kiralama detaylarını günceller
    def guncelKiralamaDetaylariGuncelle(self):
        # Eğer mevcut bir kiralama varsa, onun bilgilerini göster
        mevcut_kiralama = next((kiralama for kiralama in self.arac.gecmis_kiralamalar if kiralama['bitis_tarihi'] is None), None)
    
        if mevcut_kiralama is None:
            # Eğer mevcut bir kiralama yoksa, UI'ı buna göre güncelle
            self.guncelKiralamaDetaylari.setText("Şu anda devam eden bir kiralama bulunmamaktadır.")
            return  # Güncellenecek başka bir şey olmadığı için fonksiyondan çık

        # QDateTime'i datetime.datetime'e dönüştür, gerekiyorsa
        suanki_zaman = QDateTime.currentDateTime().toPyDateTime()
        if isinstance(mevcut_kiralama['baslangic_tarihi'], QDateTime):
            baslangic_tarihi = mevcut_kiralama['baslangic_tarihi'].toPyDateTime()
        else:
            baslangic_tarihi = mevcut_kiralama['baslangic_tarihi']

        # Geçen süreyi saat cinsinden hesapla
        gecen_sure = (suanki_zaman - baslangic_tarihi).total_seconds() / 3600
        biriken_ucret = gecen_sure * self.arac.saatlik_ucret
        self.guncelKiralamaDetaylari.setText(f"Güncel Kiralama: Süre: {gecen_sure:.2f} saat\nMüşteri: {mevcut_kiralama['musteri'].ad}\nTel: {mevcut_kiralama['musteri'].telefon}\nTC: {mevcut_kiralama['musteri'].kimlik_no},\nMaliyet: {biriken_ucret:.2f} TL")
        self.guncelKiralamaDetaylari.setStyleSheet("QLabel { color: red; font-weight: bold; font-size: 20px; font-family: Calibri; }")

    # kiralama sonlandırma işlemini gerçekleştirir
    def kiralamaSonlandir(self):
        self.kiralama_sistemi.kiralamaBitir(self.arac.plaka, datetime.now())
        self.guncelKiralamaDetaylariGuncelle()
        QMessageBox.information(self, 'Başarılı', 'Kiralama başarıyla sonlandırıldı')
        self.kiralamaSonlandi.emit()
        self.close()
  