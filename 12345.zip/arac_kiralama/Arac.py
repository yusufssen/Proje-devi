
'''
araçların özelliklerini ve durumlarını tutan sınıf
'''
class Arac:
    def __init__(self, plaka, marka, model, saatlik_ucret):
        self.plaka = plaka
        self.marka = marka
        self.model = model
        self.saatlik_ucret = saatlik_ucret
        self.kiralik = False
        self.gecmis_kiralamalar = []