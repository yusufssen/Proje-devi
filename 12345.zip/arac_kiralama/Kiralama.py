from Arac import Arac
from Musteri import Musteri
from datetime import datetime, timedelta

'''
bu sınıf, araç kiralama işlemlerini gerçekleştirir, araçları ve kiralamaları yönetir
'''
class Kiralama:
    def __init__(self):
        self.arabalar = []
        # test amaçlı verileri otomatik ekle
        self.verileri_otomatik_ekle()

# araç ekler
    def aracEkle(self, arac):
        for existing_arac in self.arabalar:
            if existing_arac.plaka == arac.plaka:
                raise ValueError("Bu plaka ile bir araç zaten var.")
        self.arabalar.append(arac)

# araç kiralama işlemini gerçekleştirir, aracı kiralayan müşteriyi ve kiralama tarihini alır, aracı kiralar, kiralama bilgilerini kaydeder, aracın kiralık durumunu günceller
    def aracKiralama(self, arac_plaka, musteri, baslangic_tarihi):
        arac = next((a for a in self.arabalar if a.plaka == arac_plaka), None)
        if not arac:
            raise ValueError("Arac bulunamadi")
        if arac.kiralik:
            raise ValueError("Araç zaten kiralanmış.")
        arac.kiralik = True
        kiralama = {
            'musteri': musteri,
            'baslangic_tarihi': baslangic_tarihi,
            'bitis_tarihi': None,
            'ucret': 0  # Kiralama bitince hesaplanacak
        }
        arac.gecmis_kiralamalar.append(kiralama)

# aracı kiralayan müşteriyi ve kiralama bitiş tarihini alır, aracın kiralık durumunu günceller, kiralama bilgilerini günceller, kiralama ücretini hesaplar
    def kiralamaBitir(self, arac_plaka, bitis_tarihi):
        arac = next((a for a in self.arabalar if a.plaka == arac_plaka), None)
        if not arac or not arac.kiralik:
            raise ValueError("Bu araç kiralanmamış.")
        kiralama = next((k for k in arac.gecmis_kiralamalar if k['bitis_tarihi'] is None), None)
        if kiralama:
            kiralama['bitis_tarihi'] = bitis_tarihi
            baslangic_tarihi = kiralama['baslangic_tarihi']
            sure = (bitis_tarihi - baslangic_tarihi).total_seconds() / 3600 + 1  # +1 to round up hours
            kiralama['ucret'] = sure * arac.saatlik_ucret
            arac.kiralik = False

# test amaçlı verileri otomatik ekler
    def verileri_otomatik_ekle(self):
        # Örnek araçlar oluştur
        araclar = [
            Arac("34ABC123", "Toyota", "Corolla", 100),
            Arac("34XYZ789", "Ford", "Focus", 90),
            Arac("06DEF456", "Honda", "Civic", 110)
        ]

        # Örnek müşteriler oluştur
        musteriler = [
            Musteri("Ali Veli", "5554443322", "12345678901"),
            Musteri("Ayşe Yılmaz", "5556667788", "98765432109")
        ]

        # Sisteme araçları ekle
        for arac in araclar:
            self.aracEkle(arac)

        # Kiralamaları simüle et
        simdiki_zaman = datetime.now()
        kiralama_baslangic = simdiki_zaman - timedelta(days=2)
        kiralama_bitis = simdiki_zaman - timedelta(days=1)

        # İlk kiralama, devam ediyor
        self.aracKiralama(araclar[0].plaka, musteriler[0], kiralama_baslangic)
        
        # İkinci kiralama, tamamlandı
        self.aracKiralama(araclar[1].plaka, musteriler[1], kiralama_baslangic)
        self.kiralamaBitir(araclar[1].plaka, kiralama_bitis)