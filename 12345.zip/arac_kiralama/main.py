from PyQt5.QtWidgets import QApplication, QComboBox, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,  QPushButton, QLineEdit, QMessageBox, QTableWidget, QTableWidgetItem
from PyQt5 import QtGui
import sys
from datetime import datetime
from Arac import Arac
from Musteri import Musteri
from Kiralama import Kiralama
from AracDetay import DetayPenceresi

'''
Bu sınıf, araç kiralama sisteminin ana penceresini oluşturur.
Bu pencerede araç ekleme, araç kiralama ve araç listeleme işlemleri yapılabilir.
Uygulamanın özellikleri:
- Araç ekleme: Plaka, marka, model ve saatlik ücret bilgileri girilerek araç eklenebilir.
- Araç kiralama: Müşteri adı, telefon numarası ve kimlik numarası girilerek araç kiralanabilir.
- Araç listeleme: Kiralık ve müsait araçlar listelenebilir.
- Araç detayı: Kiralanan araçların detay bilgileri görüntülenebilir. Geçmiş kiralama bilgileri ve kiralama sonlandırma işlemi yapılabilir.
- Ücret hesaplama: Kiralama başlangıç ve bitiş tarihleri arasındaki süre hesaplanarak kiralama ücreti hesaplanır.
- Hata yönetimi: Kullanıcı hatalı girişlerde uyarılır.
'''
class AnaPencere(QMainWindow):
    def __init__(self):
        super().__init__()
        self.kiralama_sistemi = Kiralama()
        self.initUI()

# pencerenin arayüzünü oluşturur
    def initUI(self):
        self.setWindowTitle('Araç Kiralama Sistemi')
        self.setGeometry(100, 100, 800, 600)
        self.main_layout = QVBoxLayout()

        self.aracEklemeUI()
        self.aracKiralamaUI()
        self.aracListesiUI()

        container = QWidget()
        container.setLayout(self.main_layout)
        self.setCentralWidget(container)

# araç ekleme alanını oluşturur
    def aracEklemeUI(self):
        layout = QHBoxLayout()

        self.plaka_girisi = QLineEdit()
        self.plaka_girisi.setPlaceholderText('Plaka Giriniz')
        layout.addWidget(self.plaka_girisi)

        self.marka_girisi = QLineEdit()
        self.marka_girisi.setPlaceholderText('Marka Giriniz')
        layout.addWidget(self.marka_girisi)

        self.model_girisi = QLineEdit()
        self.model_girisi.setPlaceholderText('Model Giriniz')
        layout.addWidget(self.model_girisi)

        
        self.saatlik_ucret_girisi = QLineEdit()
        self.saatlik_ucret_girisi.setPlaceholderText('Saatlik Ücret Giriniz')
        self.saatlik_ucret_girisi.setValidator(QtGui.QDoubleValidator()) # yalnızca sayısal değerlerin girilebilmesi için
        layout.addWidget(self.saatlik_ucret_girisi)

        arac_ekle_butonu = QPushButton('Araç Ekle', self)
        arac_ekle_butonu.clicked.connect(self.aracEkle)
        layout.addWidget(arac_ekle_butonu)

        self.main_layout.addLayout(layout)

# araç ekleme işlemini gerçekleştiri
    def aracEkle(self):
        plaka = self.plaka_girisi.text()
        marka = self.marka_girisi.text()
        model = self.model_girisi.text()
        saatlik_ucret = float(self.saatlik_ucret_girisi.text())
        yeni_arac = Arac(plaka, marka, model, saatlik_ucret)
        try:
            self.kiralama_sistemi.aracEkle(yeni_arac)
            QMessageBox.information(self, 'Başarılı', 'Araç başarıyla eklendi')
            self.aracListesiniGuncelle()
        except ValueError as e:
            QMessageBox.warning(self, 'Hata', str(e))

# araç kiralama alanını oluşturur
    def aracKiralamaUI(self):
        layout = QHBoxLayout()

        self.arac_secimi = QComboBox(self)
        layout.addWidget(self.arac_secimi)

        self.musteri_adi_girisi = QLineEdit()
        self.musteri_adi_girisi.setPlaceholderText('Müşteri Adı Giriniz')
        layout.addWidget(self.musteri_adi_girisi)

        self.musteri_telefon_girisi = QLineEdit()
        self.musteri_telefon_girisi.setPlaceholderText('Müşteri Telefon Giriniz')
        self.musteri_telefon_girisi.setValidator(QtGui.QIntValidator()) # yalnızca sayısal değerlerin girilebilmesi için
        layout.addWidget(self.musteri_telefon_girisi)
        

        self.musteri_kimlik_girisi = QLineEdit()
        self.musteri_kimlik_girisi.setPlaceholderText('Müşteri Kimlik No Giriniz')
        self.musteri_kimlik_girisi.setValidator(QtGui.QIntValidator()) # yalnızca sayısal değerlerin girilebilmesi için
        layout.addWidget(self.musteri_kimlik_girisi)

        kiralama_butonu = QPushButton('Kiralama Yap', self)
        kiralama_butonu.clicked.connect(self.aracKiralama)
        layout.addWidget(kiralama_butonu)

        self.main_layout.addLayout(layout)

# araç listesi alanını oluşturur
    def aracKiralama(self):
        selected_plaka = self.arac_secimi.currentText().split(' - ')[0]
        musteri_adi = self.musteri_adi_girisi.text()
        musteri_telefon = self.musteri_telefon_girisi.text()
        musteri_kimlik = self.musteri_kimlik_girisi.text()
        musteri = Musteri(musteri_adi, musteri_telefon, musteri_kimlik)
        baslangic_tarihi = datetime.now()
        try:
            self.kiralama_sistemi.aracKiralama(selected_plaka, musteri, baslangic_tarihi)
            QMessageBox.information(self, 'Başarılı', 'Kiralama işlemi başarılı')
            self.aracListesiniGuncelle()
        except ValueError as e:
            QMessageBox.warning(self, 'Hata', str(e))

# araç listesi alanını oluşturur
    def aracListesiUI(self):
        self.arac_tablosu = QTableWidget(0, 4)
        self.arac_tablosu.setHorizontalHeaderLabels(['Plaka', 'Marka-Model', 'Durum', 'Aksiyon'])
        self.arac_tablosu.setColumnWidth(0, 100)
        self.arac_tablosu.setColumnWidth(1, 200)
        self.arac_tablosu.setColumnWidth(2, 250)
        self.arac_tablosu.setColumnWidth(3, 100)
        self.arac_tablosu.setEditTriggers(QTableWidget.NoEditTriggers)
        self.main_layout.addWidget(self.arac_tablosu)
        self.aracListesiniGuncelle()

# araç listesini günceller
    def aracListesiniGuncelle(self):
        self.arac_secimi.clear()

        self.arac_tablosu.setRowCount(0)
        for arac in self.kiralama_sistemi.arabalar:
            row = self.arac_tablosu.rowCount()
            self.arac_tablosu.insertRow(row)
            self.arac_tablosu.setItem(row, 0, QTableWidgetItem(arac.plaka))
            self.arac_tablosu.setItem(row, 1, QTableWidgetItem(f"{arac.marka} - {arac.model}"))
            self.arac_secimi.addItem(f"{arac.plaka} - {arac.marka} {arac.model}")

            if arac.kiralik:
                son_kiralama = arac.gecmis_kiralamalar[-1]
                baslangic_tarihi = son_kiralama['baslangic_tarihi'].strftime("%Y-%m-%d %H:%M")
                musteri_tel = son_kiralama['musteri'].telefon
                durum = f"Kirada {baslangic_tarihi}, Tel: {musteri_tel}"
            else:
                durum = "Müsait"

            self.arac_tablosu.setItem(row, 2, QTableWidgetItem(durum))
            self.aksiyonButonuEkle(row, arac)

# araç detay butonunu ekler
    def aksiyonButonuEkle(self, row, arac):
        btn = QPushButton('Detay')
        btn.clicked.connect(lambda: self.detayPenceresiAc(arac))
        self.arac_tablosu.setCellWidget(row, 3, btn)

# araç detay penceresini açar
    def detayPenceresiAc(self, arac):
        detay_penceresi = DetayPenceresi(arac, self.kiralama_sistemi, self)
        detay_penceresi.kiralamaSonlandi.connect(self.aracListesiniGuncelle)
        detay_penceresi.show()

# araç kiralama sistemi uygulamasını başlatır
if __name__ == '__main__':
    app = QApplication(sys.argv)
    ana_pencere = AnaPencere()
    ana_pencere.show()
    sys.exit(app.exec_())